package com.library.app;

import com.mongodb.client.*;
import org.bson.Document;
import static com.mongodb.client.model.Filters.*;

public class BookOperations {
    static MongoClient client = MongoClients.create("mongodb://localhost:27017");
    static MongoDatabase db = client.getDatabase("LibraryDB");
    static MongoCollection<Document> books = db.getCollection("books");

    public static void addBook(Document book) {
        books.insertOne(book);
    }

    public static void deleteBook(String id) {
        books.deleteOne(eq("id", id));
    }

    public static Document checkAvailability(String name) {
        return books.find(eq("name", name)).first();
    }
}
