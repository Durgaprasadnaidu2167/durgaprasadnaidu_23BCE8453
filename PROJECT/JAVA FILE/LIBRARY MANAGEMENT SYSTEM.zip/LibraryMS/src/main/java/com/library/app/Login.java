package com.library.app;

import com.mongodb.client.*;
import org.bson.Document;
import static com.mongodb.client.model.Filters.*;

public class Login {
    static MongoClient client = MongoClients.create("mongodb://localhost:27017");
    static MongoDatabase db = client.getDatabase("LibraryDB");
    static MongoCollection<Document> users = db.getCollection("users");

    public static boolean checkLogin(String username, String password) {
        Document user = users.find(and(eq("username", username), eq("password", password))).first();
        return user != null;
    }
}
