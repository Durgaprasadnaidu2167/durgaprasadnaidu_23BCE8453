package com.library.app;

import static spark.Spark.*;

import org.json.JSONObject;
import org.bson.Document;

public class Main {
    public static void main(String[] args) {

        port(4567);

        // Login API
        post("/login", (req, res) -> {
            JSONObject json = new JSONObject(req.body());
            boolean isValid = Login.checkLogin(json.getString("username"), json.getString("password"));
            return isValid ? "Login Successful" : "Invalid Credentials";
        });

        // Add Book
        post("/addBook", (req, res) -> {
            JSONObject json = new JSONObject(req.body());
            Document book = new Document("id", json.getString("id"))
                    .append("name", json.getString("name"))
                    .append("author", json.getString("author"))
                    .append("no_of_book_available", json.getInt("no_of_book_available"));
            BookOperations.addBook(book);
            return "Book Added";
        });

        // Delete Book
        delete("/deleteBook/:id", (req, res) -> {
            String id = req.params(":id");
            BookOperations.deleteBook(id);
            return "Book Deleted";
        });

        // Check Availability
        get("/checkAvailability/:name", (req, res) -> {
            String name = req.params(":name");
            Document result = BookOperations.checkAvailability(name);
            return (result != null) ? result.toJson() : "Book Not Found";
        });

        // Staff list
        get("/staff", (req, res) -> {
            return StaffOperations.getAllStaff();
        });
    }
}
