package com.library.app;

import com.mongodb.client.*;
import org.bson.Document;
import org.bson.json.JsonWriterSettings;

import java.util.ArrayList;
import java.util.List;

public class StaffOperations {
    static MongoClient client = MongoClients.create("mongodb://localhost:27017");
    static MongoDatabase db = client.getDatabase("LibraryDB");
    static MongoCollection<Document> staff = db.getCollection("staff");

    public static String getAllStaff() {
        List<String> staffList = new ArrayList<>();
        for (Document doc : staff.find()) {
            staffList.add(doc.toJson(JsonWriterSettings.builder().indent(true).build()));
        }
        return staffList.toString();
    }
}
